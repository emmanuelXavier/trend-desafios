# coding=UTF-8

import re
from unicodedata import normalize
# faz tokenize nos twitters 
def tokenize_twitter(twitter):
	processed_twitter = []
	# verifica o tipo da variável
	if (isinstance(twitter, unicode) is True):
		# remove as acentuações das palavras
		remove_accent = normalize('NFKD', twitter).encode('ASCII','ignore').decode('ASCII')
		# remove caracteres especiais
		remove_special_characters = re.sub('[^a-zA-Z0-9 \\\]', '', remove_accent)
		# transforma todas as palavras em minusculas
		word_lower = remove_special_characters.lower()
		processed_twitter.append(str(word_lower))
	return (processed_twitter)