# coding=UTF-8

import math
import csv
# cria um arquivo csv de armazenamento (dataset)
def create_dataset(data, path):
    csv_fit = csv.writer(open(path, "wb"))
    # escreve a linha completa do data no arquivo
    for text in data:
        line = []
        for term in text:
            for x in term:
                line.append(x)
        csv_fit.writerow(line)
# abre um arquivo csv
def open_dataset(dataset):
    with open(dataset, 'rb') as csvfile: 
        lines = csv.reader(csvfile)
        file_dataset = list(lines)
    return (file_dataset)
# verifica a frequência de um termo. Reproduzido do site: http://aimotion.blogspot.com.br/2011/12/machine-learning-with-python-meeting-tf.html
def frequency(term, text):
    return text.count(term)
# Reproduzido do site: http://aimotion.blogspot.com.br/2011/12/machine-learning-with-python-meeting-tf.html
def tf(term, text):
    return (frequency(term, text)/float(len(text)))
# Reproduzido do site: http://aimotion.blogspot.com.br/2011/12/machine-learning-with-python-meeting-tf.html
def num_texts_containing(term, list_of_texts):
    count = 0
    for text in list_of_texts:
        if frequency(term, text) > 0:
            count += 1
    return 1 + count
# Reproduzido do site: http://aimotion.blogspot.com.br/2011/12/machine-learning-with-python-meeting-tf.html
def idf(term, list_of_texts):
    return math.log(len(list_of_texts)/float(num_texts_containing(term, list_of_texts)))
# códifica os textos
def encoding_tfidf(data):
    texts = []
    dataset = []
    # pega todos os texts dos twitters
    texts_twitters = [text[6].split() for text in data]
    language = [lan[1].split() for lan in data]
    # apaga a descrição inicial dos atributos
    del texts_twitters[0]
    # apaga a descrição inicial dos atributos
    del language[0]
    # filtra os twitters, pela lingua portuguesa
    for i,lang in enumerate(language):
        if(lang[0] == 'pt'):
            # salva os texts em uma lista
            texts.append(texts_twitters[i])
    # percorre todos os texts
    for i,text in enumerate(texts):
        line = []
        # percorre cada termo do texto do twitter
        for j,term in enumerate(text):
            # verifica a frequência do termo
            result_frequency = frequency(term, text)
            result_tf = tf(term, text)
            # verifica a quantidade de textos que o termo aparece
            num_texts_term = num_texts_containing(term, texts)
            # valor de idf do termo do texto
            result_idf = idf(term, texts)
            # valor de tf-idf do termo do texto
            tf_idf = result_tf * result_idf
            # filtra os termos pelo valor de tf-idf e que contenham a sigla de retwitter e links
            if(tf_idf > 0.1 and len(texts[i][j]) > 2 and texts[i][j] != 'rt' and 'http' not in texts[i][j]):
                temp_line = tf_idf, texts[i][j]
                line.append(temp_line)
        dataset.append(line)
    return (dataset)
# abre o dataset com os twitters
data = open_dataset('dataset-twitter.csv')
# codifica a representação dos dados 
dataset = encoding_tfidf(data)
# salva o novo dataset, apenas com os termos originais e códificados
create_dataset(dataset, 'encoding-twitter.csv')