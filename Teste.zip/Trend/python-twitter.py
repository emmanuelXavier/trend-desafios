# coding=UTF-8
import json
import csv
import os
import twitter
import urllib
from tokenize import *
from threading import Timer
from requests_oauthlib import OAuth1Session
# chaves fornecidas pelo twitter 
keys = {
	'API_KEY':'ZxY3yyqT8P2cUCCXafFKGQZxC',
	'API_SECRET':'3SKG3O8iVDkVyV7QFuMd7ifCWxnlK0J3enLq0USWUY2WnRPyb8',
	'ACCESS_TOKEN':'42249678-AUA5oS4dS1fWvgQ1P0Clxyd7wrJoblsGyQAa2PPli',
	'ACCESS_TOKEN_SECRET':'cmr2vjDf7ndKC8H8e2yNadIxrqoMX9PpukwisCXSTt8Sc'
}
# autenticar o acesso
def authenticate(keys):
	return(twitter.Api(keys['API_KEY'], keys['API_SECRET'], keys['ACCESS_TOKEN'], keys['ACCESS_TOKEN_SECRET']))
# autenticar o acesso
def authenticate_OAuth(keys):
	session = OAuth1Session(keys['API_KEY'], keys['API_SECRET'], keys['ACCESS_TOKEN'], keys['ACCESS_TOKEN_SECRET'])
	return(session)
# cria um arquivo csv de armazenamento (dataset)
def create_dataset(data, path):
	csv_fit = csv.writer(open(path, "wb"))
	# escreve a linha completa do data no arquivo
	for i in range(len(data)):
		csv_fit.writerow(data[i])
# cria um arquivo csv de armazenamento (dataset)
def create_dataset_trends(data, path):
	csv_fit = csv.writer(open(path, "wb"))
	# escreve a linha completa do data no arquivo
	for line in data:
		csv_fit.writerow(line)
# abre o arquivo de dataset já criado
def open_dataset(dataset):
    with open(dataset, 'rb') as csvfile: 
        lines = csv.reader(csvfile)
        file_dataset = list(lines)
    return (file_dataset)
# busca os últimos x (count) twitters da timeline do usuário autenticado
def get_twitters_timeline(api,session):
	information = []
	# inseri os rotulos dos atributos (caso o dataset ainda não tenha sido criado), caso já criado, comentar as duas primeiras linhas abaixo
	#labels = 'id-user','language','location','time-zone','likes','retweet','text','hashtags','user-mentions','urls','id-twitter','created-at'
	#information.append(labels)
	# o máximo que a API retorna é 20 twitters, para essa requisição da timeline
	twitters = api.GetHomeTimeline(count=20)
	# faz uma sessão para retornar os trending topics do mundo e do Brasil atualmente
	response = session.get("https://api.twitter.com/1.1/trends/place.json?id=1")
	worlds = json.loads(response.content)[0]["trends"]
	response = session.get("https://api.twitter.com/1.1/trends/place.json?id=23424768")
	brazils = json.loads(response.content)[0]["trends"]
	trend_worlds = [trend_wo['name'] for trend_wo in worlds]
	trend_brazil = [trend_br['name'] for trend_br in brazils]
	trends = []
	len_trends =  len(trend_worlds),len(trend_brazil)
	len_max = max(len_trends)
	while (len(trend_worlds) < len_max):
		trend_worlds.append('')
	while (len(trend_brazil) < len_max):
		trend_brazil.append('')
	for x in range(len(trend_worlds)):
		temp1 = tokenize_twitter(trend_worlds[x])
		temp2 = tokenize_twitter(trend_brazil[x])
		aux = temp1[-1], temp2[-1]
		trends.append(aux)
	# cria o dataset com as trending topics
	create_dataset_trends(trends, 'trending-topics.csv')
	for twitter in twitters:
		temp = twitter.media
		text_tokenize = tokenize_twitter(twitter.text)
		location_tokenize = tokenize_twitter(twitter.user.location)
		time_zone = tokenize_twitter(twitter.user.time_zone)
		created_at = tokenize_twitter(twitter.created_at)
		if not os.path.exists('media_urls/'):
			os.makedirs('media_urls/')
		if (temp != None and os.path.isfile('media_urls/'+str(twitter.id)+'.jpg') is False):
			url_image = temp[0].media_url
			urllib.urlretrieve(url_image, 'media_urls/'+str(twitter.id)+'.jpg')
		if (text_tokenize != []):
			temp = (
				twitter.user.id,twitter.user.lang,location_tokenize[-1],time_zone,twitter.favorite_count,twitter.retweet_count,
				text_tokenize[-1],twitter.hashtags,twitter.user_mentions,twitter.urls,twitter.id,created_at[-1]
			)
			information.append(temp)
	return (information)
# função para executar o código em intervalos de tempo. Reproduzido do site: http://wiki.python.org.br/ExecutandoEmIntervalos 
def time_execution(function,interval,*params,**kwparams):
	def setTimer(wrapper):
		wrapper.timer = Timer(interval, wrapper)
		wrapper.timer.start()
	def wrapper():
		function(*params, **kwparams)
		setTimer(wrapper)
	setTimer(wrapper)
	return wrapper
	def clearInterval(wrapper):
		wrapper.timer.cancel()
# principal
def main():
	filtered = []
	# faz a autenticação com as chaves do twitter
	api = authenticate(keys)
	session = authenticate_OAuth(keys)
	# captura os 20 últimos twitters da timeline de autenticação
	data = get_twitters_timeline(api,session)
	# o comando comentado abaixo cria o dataset pela primeira vez (caso ainda não exista)
	#create_dataset(data, 'dataset-twitter.csv')
	# abre o dataset
	dataset = open_dataset('dataset-twitter.csv')
	# recupera todos os ids dos twitters no dataset
	ids = [dataset[x][-2] for x in range(len(dataset))]
	# percorre os "novos" twitters captados
	for i,line in enumerate(data):
		# verifica se o twitter atual não está no dataset
		if (str(line[-2]) not in ids):
			# separa todos os twitters que ainda não estão no dataset
			filtered.append(line)
		if (str(line[-2]) in ids):
			index_id = ids.index(str(line[-2]))
			dataset[index_id][4] = data[i][4]
			dataset[index_id][5] = data[i][5]
	# adiciona os novos twitters que ainda não estavam no dataset
	for x in range(len(filtered)):
		dataset.append(filtered[x])
	# substitui o dataset pelo novo atualizado
	create_dataset(dataset, 'dataset-twitter.csv')
main()
# executa a cada três minutos
interval = time_execution(main, 180)
