# coding=UTF-8

import matplotlib.pyplot as plt
# plota os grupos formados pelo k-means
def plotagem_kmeans(data,clusters,distances,nome_fig):
	# define 10 cores para atribuir a cada grupo
	colors = {
		0:'#FFC85B',1:'#BB5A5A',2:'#F1F1F1',3:'#323232',4:'#BB5A5A',
		5:'#499491',6:'#BDC3C7',7:'#B4BB72',8:'#BDC3C7',9:'#8EA5EB',
	}
	# plota cada ponto representando o twitter pelo termo com maior valor de tf-idf
	for j,tf_idf in enumerate(data):
		if (len(tf_idf) > 1):
			term = max(tf_idf)
			plt.plot(distances[j], term, ls = '-', marker = 'o', ms = 10.0, c = colors[clusters[j]], alpha='0.5')
	plt.ylabel('TF-IDF', fontsize=12)
	plt.xlabel('Distances', fontsize=12)
	plt.grid(True, zorder=5)
	plt.savefig(nome_fig)
	plt.close('all')