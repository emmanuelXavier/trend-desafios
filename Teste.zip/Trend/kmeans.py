# coding=UTF-8
import csv
import numpy as np
from sklearn.cluster import KMeans
from plot import *
# abre um arquivo csv
def open_dataset(dataset):
    with open(dataset, 'rb') as csvfile: 
        lines = csv.reader(csvfile)
        file_dataset = list(lines)
    return (file_dataset)
# cria um arquivo csv
def create_dataset(data1,data2, path):
	csv_fit = csv.writer(open(path, "wb"))
	for i,terms in enumerate(data2):
		line = []
		line.append(data1[i])
		for term in enumerate(terms):
			line.append(term[1])
		csv_fit.writerow(line)
# executa o algoritmo de agrupamento k-means
def k_means(data,num_clusters):
	distances_clusters = []
	distance_space = []
	# executa o algoritmo com os parâmetros passados
	kmeans = KMeans(n_clusters=num_clusters, n_init=1000,random_state=True,precompute_distances='auto').fit(data)
	# recebe a distância de todos os twitters em relação a todos os centroides
	temp_distance_space = kmeans.transform(data, y=None)
	# recebe o número do cluster de cada twitter
	clusters = kmeans.predict(data)
	# pega a distância menor do centroind, mais próximo do twitter
	for x in temp_distance_space:
		distance_space.append(min(x))
	# retorna os cluster e as distâncias
	return (clusters,distance_space)
# abre o dataset com os twitters
data = open_dataset('encoding-twitter.csv')
list_tf_idf = []
list_terms = []
list_tf_idf_plot = []
for texts in data:
	tf_idf = [float(texts[x]) for x in range(0,len(texts),2)]
	terms = [texts[x] for x in range(1,len(texts),2)]
	list_tf_idf_plot.append(list(tf_idf))
	while (len(tf_idf) < 50):
		tf_idf.append(0.0)
	list_tf_idf.append(tf_idf)
	list_terms.append(terms)
# executa o algoritmo k-means
result_kmeans = k_means(list_tf_idf,8)
# plota o gráfico com os grupos formados
plotagem_kmeans(list_tf_idf_plot,result_kmeans[0],result_kmeans[1],'fig_result.eps')
# cria um arquivo de saída com os grupos e termos
create_dataset(result_kmeans[0],list_terms, 'clusters-twitters.csv')
